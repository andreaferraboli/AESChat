package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

public class SceneEnterServer extends Application {




    public void start(Stage stage) throws IOException {


            GridPane root=new GridPane();
            TextField t1=new TextField("inserire nome utilizzato dal server:");

            Button b1 = new Button("entra nel server");


            b1.setId("entraserver");
            b1.setOnAction(e -> {
/*
                try {
                    Client local=new Client(t1.getText(),Client.getpublicip(),6056);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
*/
                Main prymarystage = new Main();
                try {
                    prymarystage.start(stage);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            });

            root.add(b1,0,2);
            root.add(t1,0,1);

            Scene scene = new Scene(root);
            stage.setTitle("enter in the server");


            scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            stage.centerOnScreen();
            stage.setScene(scene);
            stage.show();
            }
        }

