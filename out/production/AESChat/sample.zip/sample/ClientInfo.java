package sample;

import java.net.InetAddress;
//here we are storing all clients info

public class ClientInfo {
    private InetAddress address;
    private int port;
    private String name;
    private int id;

    //constructor
    public ClientInfo(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public ClientInfo(String name, int id, InetAddress address, int port) {
        this.name = name;
        this.id = id;
        this.address = address;
        this.port = port;
    }

    //all getters
    public  String getName() {
        return name;
    }

    public  int getID() {
        return id;
    }

    public InetAddress getAddress() {
        return address;
    }

    public  int getPort() {
        return port;
    }

    public void setAddress(InetAddress address) { this.address = address; }

    public void setPort(int port) { this.port = port; }
}
