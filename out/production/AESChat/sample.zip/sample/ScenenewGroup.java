package sample;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class ScenenewGroup extends Application {

@FXML
private TextField nuovogruppo1;
    @FXML
    private TextField nuovogruppo11;

    public void start(Stage stage) throws IOException {

            GridPane g1 = FXMLLoader.load(getClass().getResource("Scenanewgroup.fxml"));
            GridPane root=new GridPane();
            Button indietro = new Button("<-");

            indietro.setId("indietro");
            indietro.setOnAction(e -> {
                //s1.interrupt();
                Main prymarystage = new Main();
                try {
                    prymarystage.start(stage);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            });

            root.add(indietro,0,0);

            root.add(g1,0,2);

            Scene scene = new Scene(root);
            stage.setTitle("New Group");


            scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            stage.centerOnScreen();
            stage.setScene(scene);
            }
            @FXML
            public void creagruppo() throws IOException {
                String nomegruppo ="group_"+ nuovogruppo1.getText();

                String path = Main.pathname+"\\" + nomegruppo + ".txt";
                nomegruppo="join #"+nuovogruppo1.getText();
                System.out.println("nomegruppo="+nomegruppo);
                System.out.println("nuovogruppo.gettext="+nuovogruppo1.getText());
                ChatClient.GroupCreation(nomegruppo);
                ChatClient.sendmessageGroup("",nuovogruppo1.getText());
                try {
                    File file = new File(path);

                    if (file.exists())
                        alert.showAlert(Alert.AlertType.ERROR, Main.owner, "Form Error!",
                                "hai già creato una chat con questo nome");
                    else if (file.createNewFile())
                        alert.showAlert(Alert.AlertType.INFORMATION, Main.owner, "Form information!",
                                "nuova chat creata");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            @FXML
            public void entragruppo() throws IOException {
                String nomegruppo ="group_"+ nuovogruppo11.getText();

                String path = Main.pathname+"\\" + nomegruppo + ".txt";
                nomegruppo="join #"+nuovogruppo11.getText();
                ChatClient.GroupCreation(nomegruppo);
                ChatClient.sendmessageGroup("",nuovogruppo11.getText());
                try {
                    File file = new File(path);

                    if (file.exists())
                        alert.showAlert(Alert.AlertType.ERROR, Main.owner, "Form Error!",
                                "hai già creato una chat con questo nome");
                    else if (file.createNewFile())
                        alert.showAlert(Alert.AlertType.INFORMATION, Main.owner, "Form information!",
                                "nuova chat creata");
                } catch (IOException e) {
                    e.printStackTrace();
                }


    }


}

