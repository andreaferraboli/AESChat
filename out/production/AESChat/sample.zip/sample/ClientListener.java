package sample;

import java.net.DatagramPacket;

public class ClientListener extends Thread{

    public void run() {


        try {
            while (true) {
                byte[] data = new byte[1024];   //byte array is an array with the message itself and it has the dimension of 1024 bytes
                DatagramPacket packet = new DatagramPacket(data, data.length);  //Datagram packet which contains the message from the byte array. We are creating this packet because we can use other useful methods in the future
                //Client.socket.receive(packet); //we are receiving a message
                String msg = new String(packet.getData());
                System.out.println(packet.getAddress()+msg);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

