package sample;

public class Counter {
    public static int counter = 0;
}
